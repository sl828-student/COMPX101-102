﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticalTest
{
    public class Medallist
    {
        //Create private fields here


        //Create public properties here


        //Create constructor here


        //Create other methods here

        

    }
}
