using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace Practest2
{
    /// <summary>
    /// Stores a design for a wall of a gallery.
    /// It contains a list of paintings and their positions, and a background colour
    /// </summary>
    class Wall
    {
        public Color BackgroundColour;

        public List<Painting> paintings;

        /// <summary>
        /// Creates a wall of a gallery.
        /// It contains a list of paintings and their positions, and a background colour
        /// </summary>
        public Wall()
        {
            BackgroundColour = Color.White;
            paintings = new List<Painting>();
        }

        /// <summary>
        /// Adds a painting to the gallery wall
        /// </summary>
        /// <param name="painting">painting to add to the wall</param>
        public void AddPainting(Painting painting)
        {
            paintings.Add(painting);
        }

        /// <summary>
        /// Checks if a (mouse) position is 'on' any paintings, and returns the painting if it does.
        /// </summary>
        /// <param name="x">x position to check</param>
        /// <param name="y">y position to check</param>
        /// <returns>painting that x,y is 'on'</returns>
        public Painting SelectPainting(int x, int y)
        {
            foreach (Painting p in paintings)
            {
                if (p.IsMouseOn(x, y))
                {
                    return p;
                }
            }
            return null;
        }
        
        /// <summary>
        /// Displays the gallery wall with any paintings on it.
        /// </summary>
        /// <param name="wall">Graphics object specifying where to draw image</param>
        public void Display(Graphics wall)
        {
            wall.Clear(BackgroundColour);
            foreach (Painting p in paintings)
            {
                p.Display(wall);
            }
        }

        /// <summary>
        /// Returns a string summarising this wall
        /// </summary>
        /// <returns>String describing this wall</returns>
        public override string ToString()
        {
            return "Wall has " + paintings.Count.ToString() + " paintings.";
        }
    }
}
