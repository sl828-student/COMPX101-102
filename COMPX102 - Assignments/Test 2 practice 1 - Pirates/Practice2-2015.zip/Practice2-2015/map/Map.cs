﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace map
{
    /// <summary>
    /// Stores a treasure map.
    /// It contains a list of directions, and a background image
    /// </summary>
    class Map
    {
        public Bitmap Background;

        public List<Direction> Directions;

        /// <summary>
        /// Creates a treasure map.
        /// It contains a list of directions, and a background image
        /// </summary>
        public Map()
        {
            Background = null;
            Directions = new List<Direction>();
        }

        /// <summary>
        /// Adds a direction to the map
        /// </summary>
        /// <param name="landmark">direction to add to the map</param>
        public void AddDirection(Direction direction)
        {
            Directions.Add(direction);
        }

        /// <summary>
        /// Checks if a (mouse) position is 'on' any direction, and returns the direction if it does.
        /// </summary>
        /// <param name="x">x position to check</param>
        /// <param name="y">y position to check</param>
        /// <returns>direction that x,y is 'on'</returns>
        public Direction SelectDirection(int x, int y)
        {
            foreach (Direction d in Directions)
            {
                if (d.IsMouseOn(x, y))
                {
                    return d;
                }
            }
            return null;
        }
        
        /// <summary>
        /// Displays the map of directions.
        /// </summary>
        /// <param name="paper">Graphics object specifying where to draw map</param>
        public void Display(Graphics paper)
        {
            paper.Clear(Color.White);

            // Display selected background image
            if (Background != null)
                paper.DrawImage(Background, 0, 0, paper.ClipBounds.Width,paper.ClipBounds.Height);
            // Display each stored direction
            foreach (Direction d in Directions)
            {
                d.Display(paper);
            }
        }

        /// <summary>
        /// Returns a string summarising this map
        /// </summary>
        /// <returns>string describing this map</returns>
        public override string ToString()
        {
            return "Treasure map has " + Directions.Count.ToString() + " directions stored.";
        }
    }
}
