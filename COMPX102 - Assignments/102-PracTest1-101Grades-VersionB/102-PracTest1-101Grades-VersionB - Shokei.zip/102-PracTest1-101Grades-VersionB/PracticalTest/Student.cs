﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticalTest
{
    public class Student
    {
        //Create private fields here
        private string _papercode;
        private string _trimester;
        private int _id;
        private string _qualification;
        private double _examMark;
        private double _finalMark;
        private string _finalGrade;

        private List <Student> _studentsList;


        //Create public properties here
        public string Papercode
        { 
            get { return _papercode; } 
            set { _papercode = value; }
        }
        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        public string Trimester
        {
            get { return _trimester; }
        }
        public string Qualification
        {
            get { return _qualification; }
        }
        public double ExamMark
        {
            get { return _examMark; }
        }
        public double FinalMark
        { get { return _finalMark; } }
        public string FinalGrade
        { get { return _finalGrade; } }
        public  override string  ToString()
        {
            return Papercode.PadRight(10) + "    " + Id + Trimester.PadRight(10) + Qualification.PadRight(10) + "   " + ExamMark + "   "+ FinalMark + "   " + FinalGrade;
        }

        //Create constructor here
        public Student (string paperCode, string trimester, int id, string qualification, double examMark, double finalMark, string finalGrade)
        {
            _papercode = paperCode;
            _trimester = trimester;
            _id = id;
            _qualification = qualification;
            _examMark = examMark;
            _finalMark = finalMark;
            _finalGrade = finalGrade;
            _studentsList= new List<Student>();
        }

        //Create other methods here
        /**public void DisplayStudents(ListBox listBoxDisplay)
        {
            listBoxDisplay.Items.Clear();
            foreach (Student s in _studentsList )
            {
                listBoxDisplay.Items.Add(s);
            }
        }
        **/
        
        public void CheckPaperCode(string paperCode)
        {
            if (string.IsNullOrEmpty(paperCode))
            {
                throw new ArgumentNullException("Papercode is empty");
            }
        }
        public void CheckID(int id)
        {
            if (id < 100)
            {
                throw new ArgumentOutOfRangeException("id");
            }
        }

    }
}
