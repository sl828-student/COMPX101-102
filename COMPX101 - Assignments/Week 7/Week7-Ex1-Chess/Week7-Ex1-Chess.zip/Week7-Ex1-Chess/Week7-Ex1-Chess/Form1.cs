﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week7_Ex1_Chess
{
    public partial class Form1 : Form
    {
        //The minimum size of the board
        const int MIN_BOARD_SIZE = 2;
        //The maximum size of the board
        const int MAX_BOARD_SIZE = 10;
        //The width of a square
        const int SQUARE_WIDTH = 50;
        //The height of a square
        const int SQUARE_HEIGHT = 50;

        //the colour of a Dark square (a variable since Color cannot be a const)
        Color DarkBrown = Color.SaddleBrown;

        //the colour of a Light square (a variable since Color cannot be a const)
        Color LightBrown = Color.SandyBrown;

        public Form1()
        {
            InitializeComponent();
        }
    }
}
