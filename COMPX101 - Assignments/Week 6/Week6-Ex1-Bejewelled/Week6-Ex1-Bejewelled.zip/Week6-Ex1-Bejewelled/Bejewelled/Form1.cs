﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bejewelled
{
    public partial class Form1 : Form
    {
        //the width of a jewel
        const int JEWEL_WIDTH = 50;

        //the height of a jewel
        const int JEWEL_HEIGHT = 50;

        //the number of colours that a jewel can be
        //colours in order from 0 to 6 are: red, orange, yellow, green, blue, indigo and violet
        const int NUMBER_OF_COLOURS = 7;

        //Creating and seeding the Random object for generating random numbers
        //Hint: use randomGenerator.Next(10) to generate a number from 0 to 9
        Random rand = new Random();

        public Form1()
        {
            InitializeComponent();
        }
    }
}
