﻿namespace PracticalTest1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxNumCansOrdered = new System.Windows.Forms.TextBox();
            this.textBoxNumBottlesOrdered = new System.Windows.Forms.TextBox();
            this.textBoxAmountCans = new System.Windows.Forms.TextBox();
            this.textBoxAmountBottles = new System.Windows.Forms.TextBox();
            this.textBoxTotalBeer = new System.Windows.Forms.TextBox();
            this.textBoxTotalCost = new System.Windows.Forms.TextBox();
            this.labelNumCansOrdered = new System.Windows.Forms.Label();
            this.labelNumBottlesOrdered = new System.Windows.Forms.Label();
            this.labelAmountCans = new System.Windows.Forms.Label();
            this.labelAmountBottles = new System.Windows.Forms.Label();
            this.labelTotalBeer = new System.Windows.Forms.Label();
            this.labelTotalCost = new System.Windows.Forms.Label();
            this.buttonCalculate = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.labelBrand = new System.Windows.Forms.Label();
            this.labelLitres = new System.Windows.Forms.Label();
            this.labelLitres2 = new System.Windows.Forms.Label();
            this.labelLitres3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxNumberKegs = new System.Windows.Forms.TextBox();
            this.textBoxKegsCost = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBoxNumCansOrdered
            // 
            this.textBoxNumCansOrdered.Location = new System.Drawing.Point(184, 53);
            this.textBoxNumCansOrdered.Name = "textBoxNumCansOrdered";
            this.textBoxNumCansOrdered.Size = new System.Drawing.Size(100, 20);
            this.textBoxNumCansOrdered.TabIndex = 0;
            // 
            // textBoxNumBottlesOrdered
            // 
            this.textBoxNumBottlesOrdered.Location = new System.Drawing.Point(184, 79);
            this.textBoxNumBottlesOrdered.Name = "textBoxNumBottlesOrdered";
            this.textBoxNumBottlesOrdered.Size = new System.Drawing.Size(100, 20);
            this.textBoxNumBottlesOrdered.TabIndex = 1;
            // 
            // textBoxAmountCans
            // 
            this.textBoxAmountCans.Location = new System.Drawing.Point(184, 175);
            this.textBoxAmountCans.Name = "textBoxAmountCans";
            this.textBoxAmountCans.ReadOnly = true;
            this.textBoxAmountCans.Size = new System.Drawing.Size(100, 20);
            this.textBoxAmountCans.TabIndex = 2;
            // 
            // textBoxAmountBottles
            // 
            this.textBoxAmountBottles.Location = new System.Drawing.Point(184, 200);
            this.textBoxAmountBottles.Name = "textBoxAmountBottles";
            this.textBoxAmountBottles.ReadOnly = true;
            this.textBoxAmountBottles.Size = new System.Drawing.Size(100, 20);
            this.textBoxAmountBottles.TabIndex = 3;
            // 
            // textBoxTotalBeer
            // 
            this.textBoxTotalBeer.Location = new System.Drawing.Point(184, 225);
            this.textBoxTotalBeer.Name = "textBoxTotalBeer";
            this.textBoxTotalBeer.ReadOnly = true;
            this.textBoxTotalBeer.Size = new System.Drawing.Size(100, 20);
            this.textBoxTotalBeer.TabIndex = 4;
            // 
            // textBoxTotalCost
            // 
            this.textBoxTotalCost.Location = new System.Drawing.Point(184, 250);
            this.textBoxTotalCost.Name = "textBoxTotalCost";
            this.textBoxTotalCost.ReadOnly = true;
            this.textBoxTotalCost.Size = new System.Drawing.Size(100, 20);
            this.textBoxTotalCost.TabIndex = 5;
            // 
            // labelNumCansOrdered
            // 
            this.labelNumCansOrdered.AutoSize = true;
            this.labelNumCansOrdered.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.labelNumCansOrdered.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumCansOrdered.Location = new System.Drawing.Point(30, 57);
            this.labelNumCansOrdered.Name = "labelNumCansOrdered";
            this.labelNumCansOrdered.Size = new System.Drawing.Size(148, 16);
            this.labelNumCansOrdered.TabIndex = 6;
            this.labelNumCansOrdered.Text = "Number of Cans Ordered:";
            // 
            // labelNumBottlesOrdered
            // 
            this.labelNumBottlesOrdered.AutoSize = true;
            this.labelNumBottlesOrdered.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.labelNumBottlesOrdered.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNumBottlesOrdered.Location = new System.Drawing.Point(17, 83);
            this.labelNumBottlesOrdered.Name = "labelNumBottlesOrdered";
            this.labelNumBottlesOrdered.Size = new System.Drawing.Size(161, 16);
            this.labelNumBottlesOrdered.TabIndex = 7;
            this.labelNumBottlesOrdered.Text = "Number of Bottles Ordered:";
            // 
            // labelAmountCans
            // 
            this.labelAmountCans.AutoSize = true;
            this.labelAmountCans.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.labelAmountCans.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAmountCans.Location = new System.Drawing.Point(29, 179);
            this.labelAmountCans.Name = "labelAmountCans";
            this.labelAmountCans.Size = new System.Drawing.Size(149, 16);
            this.labelAmountCans.TabIndex = 8;
            this.labelAmountCans.Text = "Amount of Beer for Cans:";
            // 
            // labelAmountBottles
            // 
            this.labelAmountBottles.AutoSize = true;
            this.labelAmountBottles.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.labelAmountBottles.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAmountBottles.Location = new System.Drawing.Point(16, 204);
            this.labelAmountBottles.Name = "labelAmountBottles";
            this.labelAmountBottles.Size = new System.Drawing.Size(162, 16);
            this.labelAmountBottles.TabIndex = 9;
            this.labelAmountBottles.Text = "Amount of Beer for Bottles:";
            // 
            // labelTotalBeer
            // 
            this.labelTotalBeer.AutoSize = true;
            this.labelTotalBeer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.labelTotalBeer.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalBeer.Location = new System.Drawing.Point(64, 229);
            this.labelTotalBeer.Name = "labelTotalBeer";
            this.labelTotalBeer.Size = new System.Drawing.Size(114, 16);
            this.labelTotalBeer.TabIndex = 10;
            this.labelTotalBeer.Text = "Total Beer Amount:";
            // 
            // labelTotalCost
            // 
            this.labelTotalCost.AutoSize = true;
            this.labelTotalCost.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.labelTotalCost.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTotalCost.Location = new System.Drawing.Point(110, 254);
            this.labelTotalCost.Name = "labelTotalCost";
            this.labelTotalCost.Size = new System.Drawing.Size(68, 16);
            this.labelTotalCost.TabIndex = 11;
            this.labelTotalCost.Text = "Total Cost:";
            // 
            // buttonCalculate
            // 
            this.buttonCalculate.BackColor = System.Drawing.Color.Black;
            this.buttonCalculate.Font = new System.Drawing.Font("Century751 SeBd BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCalculate.ForeColor = System.Drawing.SystemColors.Control;
            this.buttonCalculate.Location = new System.Drawing.Point(61, 116);
            this.buttonCalculate.Name = "buttonCalculate";
            this.buttonCalculate.Size = new System.Drawing.Size(223, 37);
            this.buttonCalculate.TabIndex = 12;
            this.buttonCalculate.Text = "Calculate Beers!";
            this.buttonCalculate.UseVisualStyleBackColor = false;
            this.buttonCalculate.Click += new System.EventHandler(this.buttonCalculate_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Font = new System.Drawing.Font("Century751 SeBd BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClear.Location = new System.Drawing.Point(61, 363);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(223, 23);
            this.buttonClear.TabIndex = 13;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.Font = new System.Drawing.Font("Century751 SeBd BT", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExit.Location = new System.Drawing.Point(61, 392);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(223, 23);
            this.buttonExit.TabIndex = 14;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // labelBrand
            // 
            this.labelBrand.AutoSize = true;
            this.labelBrand.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelBrand.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelBrand.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBrand.Location = new System.Drawing.Point(1, 9);
            this.labelBrand.Name = "labelBrand";
            this.labelBrand.Size = new System.Drawing.Size(338, 32);
            this.labelBrand.TabIndex = 15;
            this.labelBrand.Text = "Duff Breweries Beer Calculator";
            // 
            // labelLitres
            // 
            this.labelLitres.AutoSize = true;
            this.labelLitres.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLitres.Location = new System.Drawing.Point(289, 180);
            this.labelLitres.Name = "labelLitres";
            this.labelLitres.Size = new System.Drawing.Size(37, 15);
            this.labelLitres.TabIndex = 16;
            this.labelLitres.Text = "Litres";
            // 
            // labelLitres2
            // 
            this.labelLitres2.AutoSize = true;
            this.labelLitres2.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLitres2.Location = new System.Drawing.Point(289, 205);
            this.labelLitres2.Name = "labelLitres2";
            this.labelLitres2.Size = new System.Drawing.Size(37, 15);
            this.labelLitres2.TabIndex = 17;
            this.labelLitres2.Text = "Litres";
            // 
            // labelLitres3
            // 
            this.labelLitres3.AutoSize = true;
            this.labelLitres3.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLitres3.Location = new System.Drawing.Point(289, 230);
            this.labelLitres3.Name = "labelLitres3";
            this.labelLitres3.Size = new System.Drawing.Size(37, 15);
            this.labelLitres3.TabIndex = 18;
            this.labelLitres3.Text = "Litres";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(68, 279);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 21);
            this.label1.TabIndex = 19;
            this.label1.Text = "Keg Amounts:";
            // 
            // textBoxNumberKegs
            // 
            this.textBoxNumberKegs.Location = new System.Drawing.Point(184, 308);
            this.textBoxNumberKegs.Name = "textBoxNumberKegs";
            this.textBoxNumberKegs.ReadOnly = true;
            this.textBoxNumberKegs.Size = new System.Drawing.Size(100, 20);
            this.textBoxNumberKegs.TabIndex = 20;
            // 
            // textBoxKegsCost
            // 
            this.textBoxKegsCost.Location = new System.Drawing.Point(184, 334);
            this.textBoxKegsCost.Name = "textBoxKegsCost";
            this.textBoxKegsCost.ReadOnly = true;
            this.textBoxKegsCost.Size = new System.Drawing.Size(100, 20);
            this.textBoxKegsCost.TabIndex = 21;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(78, 312);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 16);
            this.label2.TabIndex = 22;
            this.label2.Text = "Number of Kegs:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label3.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(97, 338);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 16);
            this.label3.TabIndex = 23;
            this.label3.Text = "Cost of Kegs:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(289, 313);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 15);
            this.label4.TabIndex = 24;
            this.label4.Text = "Kegs";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(289, 339);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 15);
            this.label5.TabIndex = 25;
            this.label5.Text = "Kegs";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(340, 430);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxKegsCost);
            this.Controls.Add(this.textBoxNumberKegs);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.labelLitres3);
            this.Controls.Add(this.labelLitres2);
            this.Controls.Add(this.labelLitres);
            this.Controls.Add(this.labelBrand);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonCalculate);
            this.Controls.Add(this.labelTotalCost);
            this.Controls.Add(this.labelTotalBeer);
            this.Controls.Add(this.labelAmountBottles);
            this.Controls.Add(this.labelAmountCans);
            this.Controls.Add(this.labelNumBottlesOrdered);
            this.Controls.Add(this.labelNumCansOrdered);
            this.Controls.Add(this.textBoxTotalCost);
            this.Controls.Add(this.textBoxTotalBeer);
            this.Controls.Add(this.textBoxAmountBottles);
            this.Controls.Add(this.textBoxAmountCans);
            this.Controls.Add(this.textBoxNumBottlesOrdered);
            this.Controls.Add(this.textBoxNumCansOrdered);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "101 Practical Test 1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxNumCansOrdered;
        private System.Windows.Forms.TextBox textBoxNumBottlesOrdered;
        private System.Windows.Forms.TextBox textBoxAmountCans;
        private System.Windows.Forms.TextBox textBoxAmountBottles;
        private System.Windows.Forms.TextBox textBoxTotalBeer;
        private System.Windows.Forms.TextBox textBoxTotalCost;
        private System.Windows.Forms.Label labelNumCansOrdered;
        private System.Windows.Forms.Label labelNumBottlesOrdered;
        private System.Windows.Forms.Label labelAmountCans;
        private System.Windows.Forms.Label labelAmountBottles;
        private System.Windows.Forms.Label labelTotalBeer;
        private System.Windows.Forms.Label labelTotalCost;
        private System.Windows.Forms.Button buttonCalculate;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Label labelBrand;
        private System.Windows.Forms.Label labelLitres;
        private System.Windows.Forms.Label labelLitres2;
        private System.Windows.Forms.Label labelLitres3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxNumberKegs;
        private System.Windows.Forms.TextBox textBoxKegsCost;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

